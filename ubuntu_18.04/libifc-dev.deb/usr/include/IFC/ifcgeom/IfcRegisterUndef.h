﻿#ifdef SHAPES
#undef SHAPES
#endif
#ifdef SHAPE
#undef SHAPE
#endif
#ifdef WIRE
#undef WIRE
#endif
#ifdef FACE
#undef FACE
#endif
#ifdef CURVE
#undef CURVE
#endif
#ifdef CLASS
#undef CLASS
#endif